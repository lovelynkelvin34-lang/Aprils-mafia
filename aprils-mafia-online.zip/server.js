const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static("public"));

const rooms = new Map();
const PORT = process.env.PORT || 3000;

function code() {
  return crypto.randomBytes(3).toString("hex").toUpperCase();
}
function makeCode() {
  let c = code();
  while (rooms.has(c)) c = code();
  return c;
}
function shuffle(a) {
  a = [...a];
  for (let i=a.length-1;i>0;i--) {
    const j=Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
  return a;
}
function publicRoom(r) {
  return {
    code:r.code, hostId:r.hostId, phase:r.phase, day:r.day,
    players:[...r.players.values()].map(p=>({id:p.id,name:p.name,alive:p.alive}))
  };
}
function rolesFor(n) {
  const roles=["Mafia","Mafia","Police","Doctor"];
  while(roles.length<n) roles.push("Citizen");
  return shuffle(roles);
}
function emitRoom(r) {
  io.to(r.code).emit("room:update", publicRoom(r));
}
function log(r, msg) {
  r.log.unshift(msg);
  io.to(r.code).emit("game:log", r.log);
}
function living(r) { return [...r.players.values()].filter(p=>p.alive); }
function winner(r) {
  const m=living(r).filter(p=>p.role==="Mafia").length;
  const c=living(r).filter(p=>p.role!=="Mafia").length;
  if(m===0) return "CITIZENS";
  if(m>=c) return "MAFIA";
  return null;
}
function endGame(r, winnerName) {
  r.phase="ended"; r.winner=winnerName;
  io.to(r.code).emit("game:end", {
    winner:winnerName,
    roles:[...r.players.values()].map(p=>({name:p.name,role:p.role,alive:p.alive}))
  });
  emitRoom(r);
}

io.on("connection", socket=>{
  socket.on("room:create", ({name}, cb)=>{
    name=(name||"").trim().slice(0,24);
    if(!name) return cb({error:"Enter your name."});
    const c=makeCode();
    const r={code:c,hostId:socket.id,players:new Map(),phase:"lobby",day:1,
      mafiaTarget:null,doctorTarget:null,policeTarget:null,log:[],winner:null};
    r.players.set(socket.id,{id:socket.id,name,alive:true,role:null});
    rooms.set(c,r); socket.join(c); socket.data.room=c;
    cb({ok:true,code:c,me:socket.id}); emitRoom(r);
  });

  socket.on("room:join", ({code,name}, cb)=>{
    code=(code||"").trim().toUpperCase(); name=(name||"").trim().slice(0,24);
    const r=rooms.get(code);
    if(!r) return cb({error:"Room not found."});
    if(r.phase!=="lobby") return cb({error:"Game already started."});
    if(!name) return cb({error:"Enter your name."});
    if([...r.players.values()].some(p=>p.name.toLowerCase()===name.toLowerCase()))
      return cb({error:"That name is already taken."});
    r.players.set(socket.id,{id:socket.id,name,alive:true,role:null});
    socket.join(code); socket.data.room=code; cb({ok:true,code,me:socket.id}); emitRoom(r);
  });

  socket.on("game:start", ({code}, cb)=>{
    const r=rooms.get(code); if(!r || r.hostId!==socket.id) return cb({error:"Host only."});
    if(r.players.size<5) return cb({error:"Add at least 5 players."});
    const rs=rolesFor(r.players.size);
    [...r.players.values()].forEach((p,i)=>p.role=rs[i]);
    r.phase="role"; r.day=1; r.log=[];
    for(const p of r.players.values()) io.to(p.id).emit("role:private",{role:p.role});
    log(r,"🎭 The game has begun. Roles have been secretly assigned.");
    emitRoom(r); cb({ok:true});
  });

  socket.on("game:beginNight", ({code}, cb)=>{
    const r=rooms.get(code); if(!r || r.hostId!==socket.id) return cb({error:"Host only."});
    if(r.phase!=="role" && r.phase!=="day") return cb({error:"Cannot start night now."});
    r.phase="night"; r.mafiaTarget=null; r.doctorTarget=null; r.policeTarget=null;
    for(const p of r.players.values()) if(p.alive) io.to(p.id).emit("night:prompt",{role:p.role,day:r.day});
    log(r,`🌙 Night ${r.day} begins.`);
    emitRoom(r); cb({ok:true});
  });

  socket.on("action:night", ({code,targetId}, cb)=>{
    const r=rooms.get(code), p=r?.players.get(socket.id), t=r?.players.get(targetId);
    if(!r || !p || !t || !p.alive || !t.alive || r.phase!=="night") return cb({error:"Invalid action."});
    if(p.role==="Mafia") r.mafiaTarget=targetId;
    else if(p.role==="Doctor") r.doctorTarget=targetId;
    else if(p.role==="Police") {
      r.policeTarget=targetId;
      socket.emit("police:result",{target:t.name,isMafia:t.role==="Mafia"});
    } else return cb({error:"Citizens have no night action."});
    cb({ok:true});
    const mafiaDone=[...r.players.values()].filter(x=>x.alive&&x.role==="Mafia").every(x=>true);
    // Host can resolve when ready; this keeps the UI simple and supports two Mafia.
    emitRoom(r);
  });

  socket.on("night:resolve", ({code}, cb)=>{
    const r=rooms.get(code); if(!r || r.hostId!==socket.id) return cb({error:"Host only."});
    if(r.phase!=="night") return cb({error:"Not night."});
    if(r.mafiaTarget && r.mafiaTarget!==r.doctorTarget){
      const v=r.players.get(r.mafiaTarget); if(v) {v.alive=false; log(r,`💀 ${v.name} was eliminated and enters the Afterlife.`);}
    } else if(r.mafiaTarget) log(r,`💊 The Doctor saved ${r.players.get(r.mafiaTarget)?.name || "the victim"}.`);
    const w=winner(r); emitRoom(r);
    if(w) return endGame(r,w);
    r.phase="day"; emitRoom(r); cb({ok:true});
  });

  socket.on("vote", ({code,targetId}, cb)=>{
    const r=rooms.get(code), p=r?.players.get(socket.id), t=r?.players.get(targetId);
    if(!r || !p || !t || !p.alive || !t.alive || r.phase!=="day") return cb({error:"Invalid vote."});
    if(!r.votes) r.votes=new Map();
    r.votes.set(socket.id,targetId);
    const aliveCount=living(r).length;
    if(r.votes.size>=aliveCount){
      const counts={}; for(const id of r.votes.values()) counts[id]=(counts[id]||0)+1;
      const top=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
      const eliminated=top[0]?.[0];
      if(eliminated){r.players.get(eliminated).alive=false; log(r,`🗳️ ${r.players.get(eliminated).name} was voted out and enters the Afterlife.`);}
      r.votes=new Map();
      const w=winner(r); emitRoom(r);
      if(w) endGame(r,w);
      else {r.day++; r.phase="day"; emitRoom(r);}
    } else emitRoom(r);
    cb({ok:true});
  });

  socket.on("host:nextNight", ({code}, cb)=>{
    const r=rooms.get(code); if(!r || r.hostId!==socket.id) return cb({error:"Host only."});
    if(r.phase!=="day") return cb({error:"Wait for voting to finish."});
    r.phase="night"; r.mafiaTarget=null; r.doctorTarget=null; r.policeTarget=null;
    for(const p of r.players.values()) if(p.alive) io.to(p.id).emit("night:prompt",{role:p.role,day:r.day});
    log(r,`🌙 Night ${r.day} begins.`); emitRoom(r); cb({ok:true});
  });

  socket.on("disconnect", ()=>{
    const c=socket.data.room, r=rooms.get(c); if(!r)return;
    const p=r.players.get(socket.id);
    if(r.phase==="lobby") { r.players.delete(socket.id); if(socket.id===r.hostId){const first=r.players.keys().next().value;r.hostId=first||null;} }
    else if(p) p.connected=false;
    if(r.players.size===0) rooms.delete(c); else emitRoom(r);
  });
});

server.listen(PORT,()=>console.log(`April's Mafia running on port ${PORT}`));
