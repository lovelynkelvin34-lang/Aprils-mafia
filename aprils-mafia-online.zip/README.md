# April's Mafia — Online MVP

A real-time multiplayer browser Mafia game. Each friend can join the same room from their own phone.

## Included
- Private room creation + room code
- Separate phones/devices
- 2 Mafia, 1 Police, 1 Doctor, remaining Citizens
- Private role delivery
- Night actions
- Police investigation result
- Doctor protection
- Day voting
- Eliminated players become AFTERLIFE
- Automatic win detection
- Host controls
- Game log

## Run locally
1. Install Node.js.
2. In this folder run:
   npm install
   npm start
3. Open http://localhost:3000

## Put it online
Deploy this folder to any Node.js host that supports WebSockets (for example Render, Railway, Fly.io, or a VPS). The start command is `npm start`.

## Important
This is a functional MVP, not an App Store/Google Play binary. The next production pass should add:
- persistent accounts/games
- reconnect handling
- Mafia-only private coordination
- host kick/ban controls
- configurable roles
- timer/countdown
- voice/chat
- polished animations/sounds
- moderation and anti-cheat protections
